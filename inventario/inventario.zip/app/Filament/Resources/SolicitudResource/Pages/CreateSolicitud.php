<?php

namespace App\Filament\Resources\SolicitudResource\Pages;

use App\Filament\Resources\SolicitudResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSolicitud extends CreateRecord
{
    protected static string $resource = SolicitudResource::class;
}
