<?php

return [

    'title' => 'View :label',

    'breadcrumb' => 'View',

    'content' => [

        'tab' => [
            'label' => 'View',
        ],

    ],

];
